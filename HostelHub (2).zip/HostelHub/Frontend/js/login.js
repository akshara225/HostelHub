document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");

    if (!loginForm) {
        console.error("loginForm not found");
        return;
    }

    loginForm.addEventListener("submit", async (e) => {

        e.preventDefault();

        const role = document.getElementById("role").value;
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        if (!role || !email || !password) {
            alert("Please fill all fields");
            return;
        }

        try {

            const response = await fetch("http://127.0.0.1:5000/login", {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    role: role,
                    email: email,
                    password: password
                })
            });

            const data = await response.json();

            console.log("Login response:", data);

            if (data.success) {

                // Save logged-in user
                localStorage.setItem(
                    "user",
                    JSON.stringify(data.user)
                );

                // Save role
                localStorage.setItem("role", role);

                // Student dashboard
                if (role === "student") {
                    window.location.href = "student-dashboard.html";
                }

                // Warden dashboard
                else if (role === "warden") {
                    window.location.href = "warden-dashboard.html";
                }

                // Admin dashboard
                else if (role === "admin") {
                    window.location.href = "admin-dashboard.html";
                }

            } else {

                alert(data.message || "Invalid Email or Password");

            }

        } catch (error) {

            console.error("Login Error:", error);

            alert(
                "Cannot connect to server!\n\n" +
                "Make sure Backend is running on port 5000."
            );
        }

    });

});