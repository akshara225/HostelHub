let students =
JSON.parse(localStorage.getItem("students")) || [];

function addStudent(){

    const name =
    document.getElementById("studentName").value;

    const roll =
    document.getElementById("studentRoll").value;

    const room =
    document.getElementById("studentRoom").value;

    if(name==="" || roll==="" || room===""){

        alert("Fill all fields");

        return;

    }

    students.push({

        name,
        roll,
        room

    });

    localStorage.setItem(
        "students",
        JSON.stringify(students)
    );

    displayStudents();

}

function displayStudents(){

    const table =
    document.getElementById("studentTable");

    table.innerHTML="";

    students.forEach((student,index)=>{

        table.innerHTML +=`

        <tr>

        <td>${student.name}</td>

        <td>${student.roll}</td>

        <td>${student.room}</td>

        <td>

        <button onclick="deleteStudent(${index})">

        Delete

        </button>

        </td>

        </tr>

        `;

    });

}

function deleteStudent(index){

    students.splice(index,1);

    localStorage.setItem(
        "students",
        JSON.stringify(students)
    );

    displayStudents();

}

displayStudents();