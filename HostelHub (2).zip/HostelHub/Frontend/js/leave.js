const submitBtn = document.getElementById("submitLeave");

submitBtn.addEventListener("click", function () {

    const fromDate = document.getElementById("fromDate").value;
    const toDate = document.getElementById("toDate").value;
    const reason = document.getElementById("reason").value;

    if (fromDate === "" || toDate === "" || reason === "") {

        alert("Please fill all fields.");
        return;

    }

    const leaveRequest = {

        from: fromDate,
        to: toDate,
        reason: reason,
        status: "Pending"

    };

    localStorage.setItem("leaveRequest", JSON.stringify(leaveRequest));

    displayLeave();

    alert("Leave Request Submitted Successfully!");
    let notifications = JSON.parse(localStorage.getItem("notifications")) || [];

notifications.push({

    title: "Leave Request",

    message: "Your leave request has been submitted."

});

localStorage.setItem("notifications", JSON.stringify(notifications));

});
function displayLeave() {

    const leave = JSON.parse(localStorage.getItem("leaveRequest"));

    if (!leave) {
        return;
    }

    document.getElementById("fromText").innerText = leave.from;
    document.getElementById("toText").innerText = leave.to;
    document.getElementById("reasonText").innerText = leave.reason;
    document.getElementById("statusText").innerText = leave.status;

}

displayLeave();