const submitComplaint = document.getElementById("submitComplaint");

submitComplaint.addEventListener("click", function () {

    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value;

    const priority = document.querySelector('input[name="priority"]:checked');

    if (category === "" || description === "" || !priority) {

        alert("Please fill all fields.");
        return;

    }

    const complaint = {

        category: category,
        description: description,
        priority: priority.value,
        status: "Pending"

    };

    localStorage.setItem("complaint", JSON.stringify(complaint));

    displayComplaint();

    alert("Complaint Submitted Successfully!");
    let notifications = JSON.parse(localStorage.getItem("notifications")) || [];

notifications.push({

    title: "Complaint",

    message: "Your complaint has been registered."

});

localStorage.setItem("notifications", JSON.stringify(notifications));

});
function displayComplaint() {

    const complaint = JSON.parse(localStorage.getItem("complaint"));

    if (!complaint) {

        return;

    }

    document.getElementById("categoryText").innerText = complaint.category;
    document.getElementById("descriptionText").innerText = complaint.description;
    document.getElementById("priorityText").innerText = complaint.priority;
    document.getElementById("statusText").innerText = complaint.status;

}

displayComplaint();