const submitVisitor = document.getElementById("submitVisitor");

submitVisitor.addEventListener("click", function () {

    const name = document.getElementById("visitorName").value;
    const relation = document.getElementById("relationship").value;
    const date = document.getElementById("visitDate").value;
    const time = document.getElementById("visitTime").value;
    const purpose = document.getElementById("purpose").value;

    if (name === "" || relation === "" || date === "" || time === "" || purpose === "") {

        alert("Please fill all fields.");
        return;

    }

    const visitor = {

        name: name,
        relation: relation,
        date: date,
        time: time,
        purpose: purpose,
        status: "Pending"

    };

    localStorage.setItem("visitorPass", JSON.stringify(visitor));

    displayVisitor();

    alert("Visitor Pass Requested Successfully!");
    let notifications = JSON.parse(localStorage.getItem("notifications")) || [];

notifications.push({

    title: "Visitor Pass",

    message: "Your visitor pass request has been submitted."

});

localStorage.setItem("notifications", JSON.stringify(notifications));

});

function displayVisitor(){

    const visitor = JSON.parse(localStorage.getItem("visitorPass"));

    if(!visitor){

        return;

    }

    document.getElementById("nameText").innerText = visitor.name;
    document.getElementById("relationText").innerText = visitor.relation;
    document.getElementById("dateText").innerText = visitor.date;
    document.getElementById("timeText").innerText = visitor.time;
    document.getElementById("purposeText").innerText = visitor.purpose;
    document.getElementById("statusText").innerText = visitor.status;

}

displayVisitor();