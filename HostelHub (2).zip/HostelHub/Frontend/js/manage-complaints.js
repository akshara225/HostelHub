const complaintBox = document.getElementById("complaintBox");

const complaint = JSON.parse(localStorage.getItem("complaint"));

if (!complaint) {

    complaintBox.innerHTML = "<h3>No Complaints Found</h3>";

} else {

    complaintBox.innerHTML = `

    <div class="request">

        <h2>Complaint Details</h2>

        <p><strong>Category:</strong> ${complaint.category}</p>

        <p><strong>Description:</strong> ${complaint.description}</p>

        <p><strong>Priority:</strong> ${complaint.priority}</p>

        <p><strong>Status:</strong> ${complaint.status}</p>

        <br>

        <button onclick="markProgress()">🔵 In Progress</button>

        <button onclick="markResolved()">🟢 Resolved</button>

    </div>

    `;

}
function markProgress(){

    let complaint =
    JSON.parse(localStorage.getItem("complaint"));

    complaint.status="In Progress";

    localStorage.setItem(
        "complaint",
        JSON.stringify(complaint)
    );

    addNotification(
        "Complaint Update",
        "Your complaint is now In Progress."
    );

    location.reload();

}

function markResolved(){

    let complaint =
    JSON.parse(localStorage.getItem("complaint"));

    complaint.status="Resolved";

    localStorage.setItem(
        "complaint",
        JSON.stringify(complaint)
    );

    addNotification(
        "Complaint Resolved",
        "Your complaint has been resolved."
    );

    location.reload();

}
function addNotification(title,message){

    let notifications =
    JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({

        title:title,
        message:message

    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

}