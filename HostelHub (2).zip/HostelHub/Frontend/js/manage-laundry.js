const laundryBox = document.getElementById("laundryBox");

const laundry = JSON.parse(localStorage.getItem("laundryBooking"));

if (!laundry) {

    laundryBox.innerHTML = "<h3>No Laundry Bookings</h3>";

} else {

    laundryBox.innerHTML = `

    <div class="request">

        <h2>Laundry Booking</h2>

        <p><strong>Machine:</strong> ${laundry.machine}</p>

        <p><strong>Date:</strong> ${laundry.date}</p>

        <p><strong>Time:</strong> ${laundry.time}</p>

        <p><strong>Status:</strong> ${laundry.status || "Pending"}</p>

        <br>

        <button onclick="completeLaundry()">✅ Complete</button>

        <button onclick="cancelLaundry()">❌ Cancel</button>

    </div>

    `;

}
function completeLaundry(){

    let laundry = JSON.parse(localStorage.getItem("laundryBooking"));

    laundry.status = "Completed";

    localStorage.setItem("laundryBooking", JSON.stringify(laundry));

    addNotification(
        "Laundry Completed",
        "Your laundry booking has been completed."
    );

    location.reload();

}

function cancelLaundry(){

    let laundry = JSON.parse(localStorage.getItem("laundryBooking"));

    laundry.status = "Cancelled";

    localStorage.setItem("laundryBooking", JSON.stringify(laundry));

    addNotification(
        "Laundry Cancelled",
        "Your laundry booking has been cancelled."
    );

    location.reload();

}
function addNotification(title, message){

    let notifications =
    JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({

        title,
        message

    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

}