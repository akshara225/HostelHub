const notificationList = document.getElementById("notificationList");

const clearBtn = document.getElementById("clearNotifications");

function loadNotifications(){

    const notifications = JSON.parse(localStorage.getItem("notifications")) || [];

    notificationList.innerHTML = "";

    if(notifications.length === 0){

        notificationList.innerHTML = "<p>No Notifications</p>";

        return;

    }

    notifications.forEach(notification => {

        notificationList.innerHTML += `
            <div class="notification">

                <h3>${notification.title}</h3>

                <p>${notification.message}</p>

            </div>
        `;

    });

}

clearBtn.addEventListener("click", function(){

    localStorage.removeItem("notifications");

    loadNotifications();

});

loadNotifications();