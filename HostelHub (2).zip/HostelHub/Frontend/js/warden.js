const laundry = JSON.parse(localStorage.getItem("laundryBooking"));

const leave = JSON.parse(localStorage.getItem("leaveRequest"));

const complaint = JSON.parse(localStorage.getItem("complaint"));

const visitor = JSON.parse(localStorage.getItem("visitorPass"));

let count = 0;

const box = document.getElementById("requestBox");

box.innerHTML = "";

if(laundry){

count++;

document.getElementById("laundryCount").innerText=1;

box.innerHTML += `
<div class="request">
<h3>🧺 Laundry Booking</h3>
<p>${laundry.machine}</p>
<p>${laundry.date}</p>
<p>${laundry.time}</p>
</div>
`;

}

if (leave) {

    document.getElementById("leaveCount").innerText = 1;

    box.innerHTML += `
    <div class="request">

        <h3>📝 Leave Request</h3>

        <p><strong>From:</strong> ${leave.from}</p>
        <p><strong>To:</strong> ${leave.to}</p>
        <p><strong>Reason:</strong> ${leave.reason}</p>
        <p><strong>Status:</strong> ${leave.status}</p>

        <button onclick="approveLeave()">✅ Approve</button>

        <button onclick="rejectLeave()">❌ Reject</button>

    </div>
    `;

}

if(complaint){

count++;

document.getElementById("complaintCount").innerText=1;

box.innerHTML += `
<div class="request">
<h3>⚠ Complaint</h3>
<p>${complaint.category}</p>
<p>${complaint.description}</p>
</div>
`;

}

if(visitor){

count++;

document.getElementById("visitorCount").innerText=1;

box.innerHTML += `
<div class="request">
<h3>👥 Visitor Pass</h3>
<p>${visitor.name}</p>
<p>${visitor.date}</p>
<p>${visitor.time}</p>
</div>
`;

}

if(count===0){

box.innerHTML="No Requests Found.";

}
function approveLeave() {

    let leave = JSON.parse(localStorage.getItem("leaveRequest"));

    leave.status = "Approved";

    localStorage.setItem("leaveRequest", JSON.stringify(leave));

    addNotification(
        "Leave Approved",
        "Your leave request has been approved by the warden."
    );

    location.reload();

}

function rejectLeave() {

    let leave = JSON.parse(localStorage.getItem("leaveRequest"));

    leave.status = "Rejected";

    localStorage.setItem("leaveRequest", JSON.stringify(leave));

    addNotification(
        "Leave Rejected",
        "Your leave request has been rejected by the warden."
    );

    location.reload();

}
function addNotification(title, message) {

    let notifications =
        JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({

        title: title,
        message: message

    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

}