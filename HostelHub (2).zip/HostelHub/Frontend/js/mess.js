const menu = JSON.parse(localStorage.getItem("messMenu"));

if (menu) {

    document.getElementById("breakfastText").innerText = menu.breakfast;
    document.getElementById("lunchText").innerText = menu.lunch;
    document.getElementById("snacksText").innerText = menu.snacks;
    document.getElementById("dinnerText").innerText = menu.dinner;

} else {

    document.getElementById("breakfastText").innerText = "Idli, Sambar";
    document.getElementById("lunchText").innerText = "Rice, Sambar";
    document.getElementById("snacksText").innerText = "Tea, Biscuits";
    document.getElementById("dinnerText").innerText = "Chapati, Kurma";

}