document.getElementById("studentCount").innerText = 120;
document.getElementById("wardenCount").innerText = 5;
document.getElementById("roomCount").innerText = 60;
document.getElementById("complaintCount").innerText = 8;