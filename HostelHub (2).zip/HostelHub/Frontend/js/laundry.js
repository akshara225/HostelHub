const machineButtons = document.querySelectorAll(".machine-btn");

let selectedMachine = "";

machineButtons.forEach(button => {

    button.addEventListener("click", function () {

        machineButtons.forEach(btn => {
            btn.classList.remove("selected-machine");
        });

        this.classList.add("selected-machine");

        selectedMachine = this.innerText;

    });

});
const slots = document.querySelectorAll(".slot.available");

let selectedSlot = "";

slots.forEach(slot => {

    slot.addEventListener("click", function () {

        slots.forEach(s => {
            s.classList.remove("selected-slot");
        });

        this.classList.add("selected-slot");

        selectedSlot = this.innerText;

    });

});
const bookBtn = document.getElementById("bookBtn");

bookBtn.addEventListener("click", function(){

    const bookingDate = document.getElementById("bookingDate").value;

    if(selectedMachine === "" || selectedSlot === "" || bookingDate === ""){

        alert("Please select date, machine and time slot.");
        return;

    }

    const booking = {

        machine: selectedMachine,
        date: bookingDate,
        time: selectedSlot

    };

    localStorage.setItem("laundryBooking", JSON.stringify(booking));

    displayBooking();

    alert("Booking Saved Successfully!");
    let notifications = JSON.parse(localStorage.getItem("notifications")) || [];

notifications.push({

    title: "Laundry Booking",

    message: "Your laundry slot has been booked successfully."

});

localStorage.setItem("notifications", JSON.stringify(notifications));

});
function displayBooking(){

    const booking = JSON.parse(localStorage.getItem("laundryBooking"));

    if(!booking){

        return;

    }

    document.getElementById("machineText").innerText = booking.machine;

    document.getElementById("dateText").innerText = booking.date;

    document.getElementById("timeText").innerText = booking.time;
    
    document.getElementById("statusText").innerText =
    booking.status || "Pending";

}

displayBooking();