function sendBroadcast() {

    const message = document.getElementById("message").value;

    if (message === "") {

        alert("Please enter a message.");

        return;

    }

    let notifications =
        JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({

        title: "📢 Warden Announcement",

        message: message

    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

    alert("Notification Sent Successfully!");

    document.getElementById("message").value = "";

}