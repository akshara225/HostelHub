function saveSettings(){

let settings={

name:
document.getElementById("adminName").value,

email:
document.getElementById("adminEmail").value,

hostel:
document.getElementById("hostelName").value,

address:
document.getElementById("hostelAddress").value,

password:
document.getElementById("password").value

};


localStorage.setItem(
"adminSettings",
JSON.stringify(settings)
);


alert("Settings Saved Successfully!");

}