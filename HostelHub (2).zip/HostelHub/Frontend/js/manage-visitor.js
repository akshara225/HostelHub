const visitorBox = document.getElementById("visitorBox");

const visitor = JSON.parse(localStorage.getItem("visitorPass"));

if (!visitor) {

    visitorBox.innerHTML = "<h3>No Visitor Requests</h3>";

} else {

    visitorBox.innerHTML = `

    <div class="request">

        <h2>Visitor Request</h2>

        <p><strong>Name:</strong> ${visitor.name}</p>

        <p><strong>Relationship:</strong> ${visitor.relation}</p>

        <p><strong>Date:</strong> ${visitor.date}</p>

        <p><strong>Time:</strong> ${visitor.time}</p>

        <p><strong>Purpose:</strong> ${visitor.purpose}</p>

        <p><strong>Status:</strong> ${visitor.status}</p>

        <br>

        <button onclick="approveVisitor()">✅ Approve</button>

        <button onclick="rejectVisitor()">❌ Reject</button>

    </div>

    `;

}
function approveVisitor() {

    let visitor = JSON.parse(localStorage.getItem("visitorPass"));

    visitor.status = "Approved";

    localStorage.setItem("visitorPass", JSON.stringify(visitor));

    addNotification(
        "Visitor Request Approved",
        "Your visitor request has been approved by the warden."
    );

    location.reload();

}

function rejectVisitor() {

    let visitor = JSON.parse(localStorage.getItem("visitorPass"));

    visitor.status = "Rejected";

    localStorage.setItem("visitorPass", JSON.stringify(visitor));

    addNotification(
        "Visitor Request Rejected",
        "Your visitor request has been rejected by the warden."
    );

    location.reload();

}
function addNotification(title, message) {

    let notifications =
        JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({
        title: title,
        message: message
    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

}