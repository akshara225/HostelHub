let wardens =
JSON.parse(localStorage.getItem("wardens")) || [];


function addWarden(){

    let name =
    document.getElementById("wardenName").value;

    let id =
    document.getElementById("wardenId").value;

    let phone =
    document.getElementById("wardenPhone").value;


    if(name==="" || id==="" || phone===""){

        alert("Fill all fields");

        return;

    }


    wardens.push({

        name:name,
        id:id,
        phone:phone

    });


    localStorage.setItem(
        "wardens",
        JSON.stringify(wardens)
    );


    displayWardens();

}



function displayWardens(){

    let table =
    document.getElementById("wardenTable");


    table.innerHTML="";


    wardens.forEach((warden,index)=>{


        table.innerHTML += `

        <tr>

        <td>${warden.name}</td>

        <td>${warden.id}</td>

        <td>${warden.phone}</td>


        <td>

        <button onclick="deleteWarden(${index})">

        Delete

        </button>

        </td>


        </tr>

        `;


    });


}



function deleteWarden(index){


    wardens.splice(index,1);


    localStorage.setItem(
        "wardens",
        JSON.stringify(wardens)
    );


    displayWardens();


}


displayWardens();