function saveMenu() {

    const menu = {

        breakfast: document.getElementById("breakfast").value,
        lunch: document.getElementById("lunch").value,
        snacks: document.getElementById("snacks").value,
        dinner: document.getElementById("dinner").value

    };

    localStorage.setItem("messMenu", JSON.stringify(menu));

    alert("Mess Menu Updated Successfully!");

    addNotification(
        "Mess Menu Updated",
        "Today's mess menu has been updated."
    );

}

function addNotification(title, message) {

    let notifications =
        JSON.parse(localStorage.getItem("notifications")) || [];

    notifications.push({
        title,
        message
    });

    localStorage.setItem(
        "notifications",
        JSON.stringify(notifications)
    );

}