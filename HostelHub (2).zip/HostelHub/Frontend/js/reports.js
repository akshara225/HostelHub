let students =
JSON.parse(localStorage.getItem("students")) || [];


let wardens =
JSON.parse(localStorage.getItem("wardens")) || [];


let rooms =
JSON.parse(localStorage.getItem("rooms")) || [];


let complaints =
JSON.parse(localStorage.getItem("complaints")) || [];


let leaves =
JSON.parse(localStorage.getItem("leaveRequests")) || [];


let visitors =
JSON.parse(localStorage.getItem("visitorRequests")) || [];


let laundry =
JSON.parse(localStorage.getItem("laundryBookings")) || [];



document.getElementById("students").innerText =
students.length;


document.getElementById("wardens").innerText =
wardens.length;


document.getElementById("rooms").innerText =
rooms.length;


document.getElementById("complaints").innerText =
complaints.length;


document.getElementById("leaves").innerText =
leaves.length;


document.getElementById("visitors").innerText =
visitors.length;


document.getElementById("laundry").innerText =
laundry.length;