const saveBtn = document.getElementById("saveProfile");
const profileImage = document.getElementById("profileImage");
const preview = document.getElementById("profilePreview");

// Preview Image
profileImage.addEventListener("change", function(){

    const file = this.files[0];

    if(file){

        const reader = new FileReader();

        reader.onload = function(){

            preview.src = reader.result;

            localStorage.setItem("profileImage", reader.result);

        }

        reader.readAsDataURL(file);

    }

});

// Save Profile
saveBtn.addEventListener("click", function(){

    const profile={

        name:document.getElementById("name").value,
        roll:document.getElementById("roll").value,
        department:document.getElementById("department").value,
        room:document.getElementById("room").value,
        email:document.getElementById("email").value

    };

    localStorage.setItem("studentProfile",JSON.stringify(profile));

    alert("Profile Saved Successfully!");

});

// Load Profile
function loadProfile(){

    const profile=JSON.parse(localStorage.getItem("studentProfile"));

    if(profile){

        document.getElementById("name").value=profile.name;
        document.getElementById("roll").value=profile.roll;
        document.getElementById("department").value=profile.department;
        document.getElementById("room").value=profile.room;
        document.getElementById("email").value=profile.email;

    }

    const image=localStorage.getItem("profileImage");

    if(image){

        preview.src=image;

    }

}

loadProfile();