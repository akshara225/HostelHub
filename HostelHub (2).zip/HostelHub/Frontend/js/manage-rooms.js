let rooms =
JSON.parse(localStorage.getItem("rooms")) || [];



function addRoom(){

    let roomNumber =
    document.getElementById("roomNumber").value;


    let capacity =
    document.getElementById("capacity").value;


    if(roomNumber==="" || capacity===""){

        alert("Fill all fields");

        return;

    }


    rooms.push({

        roomNumber: roomNumber,
        capacity: capacity,
        occupied: 0

    });


    localStorage.setItem(
        "rooms",
        JSON.stringify(rooms)
    );


    displayRooms();

}



function displayRooms(){

    let table =
    document.getElementById("roomTable");


    table.innerHTML="";


    rooms.forEach((room,index)=>{


        let status =
        room.occupied >= room.capacity
        ? "Occupied 🔴"
        : "Available 🟢";


        table.innerHTML += `

        <tr>

        <td>${room.roomNumber}</td>

        <td>${room.capacity}</td>

        <td>${status}</td>


        <td>

        <button onclick="deleteRoom(${index})">

        Delete

        </button>

        </td>


        </tr>

        `;


    });


}



function deleteRoom(index){


    rooms.splice(index,1);


    localStorage.setItem(
        "rooms",
        JSON.stringify(rooms)
    );


    displayRooms();

}


displayRooms();