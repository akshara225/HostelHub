const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// ======================
// MySQL
// ======================

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "hostelhub"
});

db.connect((err) => {
    if (err) {
        console.error("❌ MySQL Error:", err);
    } else {
        console.log("✅ MySQL Connected");
    }
});

// ======================
// TEST
// ======================

app.get("/", (req, res) => {
    res.send("HostelHub Backend Running 🚀");
});

// ======================
// LOGIN
// ======================

app.post("/login", (req, res) => {

    const { role, email, password } = req.body;

    let table;

    if (role === "student") {
        table = "students";
    } else if (role === "warden") {
        table = "wardens";
    } else if (role === "admin") {
        table = "admins";
    } else {
        return res.json({
            success: false,
            message: "Invalid role"
        });
    }

    const sql =
        `SELECT * FROM ${table} WHERE email = ? AND password = ?`;

    db.query(sql, [email, password], (err, result) => {

        if (err) {
            console.error("Login error:", err);

            return res.status(500).json({
                success: false,
                message: "Database error"
            });
        }

        if (result.length === 0) {
            return res.json({
                success: false,
                message: "Invalid Email or Password"
            });
        }

        res.json({
            success: true,
            user: result[0]
        });

    });

});

// ======================
// SUBMIT LEAVE
// ======================

app.post("/leave", (req, res) => {

    console.log("📩 Leave request received:");
    console.log(req.body);

    const {
        student_id,
        from_date,
        to_date,
        reason
    } = req.body;

    if (!student_id || !from_date || !to_date || !reason) {

        return res.status(400).json({
            success: false,
            message: "Please fill all fields"
        });

    }

    const sql = `
        INSERT INTO leave_requests
        (student_id, from_date, to_date, reason, status)
        VALUES (?, ?, ?, ?, 'Pending')
    `;

    db.query(
        sql,
        [student_id, from_date, to_date, reason],
        (err, result) => {

            if (err) {

                console.error("❌ Leave DB Error:", err);

                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            console.log("✅ Leave saved. ID:", result.insertId);

            res.json({
                success: true,
                message: "Leave request submitted successfully",
                leave_id: result.insertId
            });

        }
    );

});

// ======================
// GET LEAVES
// ======================

app.get("/leave/:student_id", (req, res) => {

    const studentId = req.params.student_id;

    const sql = `
        SELECT *
        FROM leave_requests
        WHERE student_id = ?
        ORDER BY created_at DESC
    `;

    db.query(sql, [studentId], (err, result) => {

        if (err) {

            console.error("❌ Leave fetch error:", err);

            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            leaves: result
        });

    });

});

// ======================
// START SERVER
// ======================

app.listen(5000, () => {
    console.log("🚀 Server running on http://localhost:5000");
});