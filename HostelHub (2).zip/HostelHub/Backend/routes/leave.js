const express = require("express");

module.exports = (db) => {

    const router = express.Router();

    // Submit Leave Request
    router.post("/", (req, res) => {

        const {
            student_id,
            from_date,
            to_date,
            reason
        } = req.body;

        if (!student_id || !from_date || !to_date || !reason) {
            return res.status(400).json({
                success: false,
                message: "Please fill all fields"
            });
        }

        const sql = `
            INSERT INTO leave_requests
            (student_id, from_date, to_date, reason, status)
            VALUES (?, ?, ?, ?, 'Pending')
        `;

        db.query(
            sql,
            [student_id, from_date, to_date, reason],
            (err, result) => {

                if (err) {
                    console.error("Leave Error:", err);

                    return res.status(500).json({
                        success: false,
                        message: "Database error"
                    });
                }

                res.json({
                    success: true,
                    message: "Leave request submitted successfully",
                    leave_id: result.insertId
                });

            }
        );

    });


    // Get student's leave requests
    router.get("/:student_id", (req, res) => {

        const studentId = req.params.student_id;

        const sql = `
            SELECT *
            FROM leave_requests
            WHERE student_id = ?
            ORDER BY created_at DESC
        `;

        db.query(sql, [studentId], (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database error"
                });
            }

            res.json({
                success: true,
                leaves: result
            });

        });

    });

    return router;
};