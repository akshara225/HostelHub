const express = require("express");

module.exports = (db) => {

    const router = express.Router();

    router.post("/", (req, res) => {

        const { role, email, password } = req.body;

        // Debug
        console.log("================================");
        console.log("Login Request Received");
        console.log("Role:", role);
        console.log("Email:", email);
        console.log("Password:", password);

        let table = "";

        if (role === "student") {
            table = "students";
        } else if (role === "warden") {
            table = "wardens";
        } else if (role === "admin") {
            table = "admins";
        } else {
            return res.json({
                success: false,
                message: "Invalid role"
            });
        }

        const sql = `SELECT * FROM ${table} WHERE email=? AND password=?`;

        console.log("SQL:", sql);

        db.query(sql, [email, password], (err, result) => {

            if (err) {
                console.log("Database Error:", err);

                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            console.log("Result:", result);

            if (result.length > 0) {

                console.log("Login Successful");

                res.json({
                    success: true,
                    user: result[0]
                });

            } else {

                console.log("Invalid Email or Password");

                res.json({
                    success: false,
                    message: "Invalid Email or Password"
                });

            }

        });

    });

    return router;

};